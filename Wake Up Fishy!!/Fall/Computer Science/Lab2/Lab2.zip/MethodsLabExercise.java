//**********************************************************************************
// Class: MethodsLabExercise
//
// Student, Section: < Your name here!>, <Your lab section here!>
//
// Other Authors: K Garfield, based on previous work by Thomas Basset, 
//                Sean Holden, Casey Lane
//
// Last Modified: Sep 2017 (initial release)
//
// Notes: This file is intended for use in CS 225 Lab.
//        Instructions provided below as comments and in lab handout.
//
//**********************************************************************************

import java.util.Scanner;

public class MethodsLabExercise {
  //*** Attributes for this class -- you do not need more
  int[] data;		// This integer array will contain the data you will work with.
  int sum;		// The sum of the data elements.
  int maxElement;	// The largest data element.
  int maxMultiply;	// The largest value obtained by multiplying two data elements together.
  double average;	// The average of the data elements.
  double stdDev; 	// The standard deviation of the data elements (see lab instructions).

  //***** Begin methods: main method *****************************************
  public static void main(String[] args) {

    // Create an object of this class and ask user for data. 
    // The getDataFromUser() method has already been written for you.
    MethodsLabExercise stats = new MethodsLabExercise();
    stats.getDataFromUser();


    //***** Lab Instructions: Create methods with the following names and behaviors *****
    //  calculateSum: Finds the sum of the data and assigns to the attribute 'sum'
    //  findMax: Finds the largest data element and assigns to the attribute 'maxElement'
    //  findMaxMult: Finds the largest value that can be obtained by multiplying two 
    //               different data elements together, and assigns to attribute 'maxMultiply'
    //  calculateAverage: Calculates the average of the data and assigns to atttribute 'average'
    //  calculateStdDev: Calculates the standrd deviation of the data and assigns to 
    //                   attribute 'stdDev'. See lab handout for equations.
    //  printResults: Prints the following --
    //                Line 1: Your name
    //                Line 2: The data as input by the user
    //                Lines 3 through 7: The values of sum, maxElement, maxMultiply, average, 
    //                                   and stdDev in that order, one per line.
    //
    //  Demonstrate your work and show your source code to the lab instructors.
    //
    //  There are no other deliverables for this lab.
    //************************************************************************************* 

    }  // End of main method

  //***************************************************************************************
  // Create your methods here. "Do nothing" dummy methods have been provided. This is a
  // common programming technique that allows you to build programs bit by bit. 
  //***************************************************************************************

  public void calculateSum() {
    System.out.println("calculateSum has been called. It doesn't work yet!");
    sum = -1;
  }

  public void findMax() {
    System.out.println("findMax has been called. It doesn't work yet!");
    maxElement = -1;
  }

  public void findMaxMult() {
    System.out.println("findMaxMult has been called. It doesn't work yet!");
    maxMultiply = -1;
  }

  public void calculateAverage() {
    System.out.println("calculateAverage has been called. It doesn't work yet!");
    average = -1;
  }

  public void calculateStdDev() {
    System.out.println("calculateStdDev has been called. It doesn't work yet!");
    stdDev = -1;
  } 

  public void printResults() {
    System.out.println("printResults has been called. It doesn't work yet!");
  }


  //***** DO NOT CHANGE CODE BELOW THIS LINE.
  //***** Obtains integer data from user and stores in integer array data[].
  public void getDataFromUser() {

    Scanner in;			// To read input
    String[] numStrs;	// To store input as strings
    int[] nums;			// To store input as integers

    // Create a new Scanner to read data from the standard system input stream (i.e. command line)
    in = new Scanner(System.in);

    // Ask the user for data
    System.out.println("Enter some numbers separated by spaces, then press Enter: ");

    // Read the whole line, and split the string to get each individual number from it
    numStrs = in.nextLine().split(" ");
    nums = new int[numStrs.length];

    // Convert the array of strings to an array of ints
    for(int i = 0; i < numStrs.length; i++) {
	nums[i] = Integer.parseInt(numStrs[i]);
    }

    // Close the scanner
    in.close();

    data = nums;
  }

}
