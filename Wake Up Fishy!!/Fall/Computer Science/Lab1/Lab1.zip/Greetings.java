
//********************************************************************
//  Greetings.java       Author: Brixius
//
//  Greet the user 
//********************************************************************

public class Greetings
{
   public static void main (String[] args)
   {

      System.out.println ("\n\nGreetings to my favorite user!\n\n");

   }
}
