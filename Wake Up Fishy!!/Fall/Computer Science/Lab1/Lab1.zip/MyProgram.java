/*
 * This is a comment section
 * Here is where you will place the information
 * About the author of this code, and what this code does
*/
public class MyProgram{


	public static void main(String[] args){
		System.out.println("Hello World!");
	}


}