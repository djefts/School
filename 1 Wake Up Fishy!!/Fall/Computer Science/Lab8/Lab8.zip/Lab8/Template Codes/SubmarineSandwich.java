/** A class representing a submarine sandwich. */
public class SubmarineSandwich extends Sandwich {
  private int length; // stands for the length of current submarine sandwich instance
  
  /** constructor with no required parameter. */
  public SubmarineSandwich() {
    //TODO: Implement the constructor with no required parameter, hint: use super() and define a default value for this.length
  }
  
  /** constructor requires an integer parameter */
  public SubmarineSandwich(int length) {
    //TODO: Implement the constructor with one required parameter, hint: use super() and then set the length to this.length
  }
  
  /** constructor requires an integer parameter and a string parameter. */
  public SubmarineSandwich(int length, String breadType) {
    //TODO: Implement the constructor with two required parameters, hint: use super(breadType) and then set the length to this.length
  }
  
  /** constructor requires an integer parameter and two string parameters. */
  public SubmarineSandwich(int length, String breadType, String components) {
    //TODO: Implement the constructor with three required parameters, hint: use super(breadType, components) and then set the length to this.length
  }
  
  /** return a integer type value standing for length of current sandwich, for example, 6 inch or 12 inch. */
  public int getLength() {
    //TODO: Implement the method by returning the length attribute
  }
  
  /** return a integer type value standing for bites left to finish the sandwich. */
  @Override
  public int getBitesLeft() {
    //TODO: Implement the method by calculating (length * 2 - the number of bites)
    //To get the number of bites, think about how to call the getNumBites() method in the super class
  }
  
  /** return a string including the details of the sandwich */
  @Override
  public String toString() {
    //TODO: Override this method and include the in the reflect the new attribute length added to SubmarineSandwich class.
    //You do not need to incorporate numBites. 
  }
}
